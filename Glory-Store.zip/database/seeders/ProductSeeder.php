<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Product::create([
        //     'barcode' => '001',
        //     'num_repuesto' => '002',
        //     'name' => 'Producto Prueba',
        //     'slug' => 'producto-prueba',
        //     'price' => '2000',
        //     'cost' => '4000',
        //     'stock' => '20',
        //     'min_stock' => '10',
        //     'available' => '60',
        //     'is_active' => 1,
        // ]);

    }
}
