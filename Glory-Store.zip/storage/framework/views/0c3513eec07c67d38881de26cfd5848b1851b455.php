<?php $__env->startSection('title', 'Crear Factura | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/libs/selects/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/add-bill.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('bills')); ?>">Facturas</a>
            /
            <a>Nueva Factura</a>
        </div>
        <h2>Nueva Factura</h2>
    </div>
    <div class="container-forr">
        <form action="<?php echo e(route('bills.store')); ?>" method="post" id="form-bill">
            <?php echo csrf_field(); ?>
            <div class="divider__form divider__form_icon">
                <h2>Información básica de la factura</h2>
                <i class="fi fi-sr-comment-info"></i>
            </div>
            <section class="sect__form__p">
                <div class="form-floating form__floating__glory">
                    <input type="date" class="form-control shadow-none date-input" id="date_bill" placeholder="Fecha" name="date_bill" required>
                    <label for="floatingInputValue">Fecha</label>
                </div>
                <div class="con-select-s">
                    <label for="customer">Cliente:</label>
                    <select name="customer" id="customers">
                        <option value=""></option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>">(<?php echo e($customer->cc); ?>) - <?php echo e($customer->fullName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a class="input__add__user__bill btn-modal-add" id="btn-add-customer" href="<?php echo e(route('usuarios.create')); ?>"><i class="fi fi-br-plus-small"></i> Añadir</a>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('link.sellers.bills')): ?>
                    <div class="con-select-s">
                        <label for="seller">Vendedor:</label>
                        <select name="seller" id="sellers">
                            <option value=""></option>
                            <?php $__currentLoopData = $sellersPer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($seller->id); ?>">(<?php echo e($seller->cc); ?>) - <?php echo e($seller->fullName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $sellersRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($seller->id); ?>">(<?php echo e($seller->cc); ?>) - <?php echo e($seller->fullName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a class="input__add__user__bill btn-modal-add" id="btn-add-customer" href="<?php echo e(route('usuarios.create')); ?>"><i class="fi fi-br-plus-small"></i> Añadir</a>
                    </div>
                <?php else: ?>
                    <select name="seller" id="sellers" style="display: none">
                        <option value="<?php echo e(auth()->user()->id); ?>"> <?php echo e(auth()->user()->id); ?> </option>
                    </select>
                <?php endif; ?>
                <div class="con-select-s">
                    <label for="products">Lista de productos:</label>
                        <select name="products" id="products">
                            <option value=""></option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>" data-amount="<?php echo e($product->stock); ?>" data-img="<?php echo e($product->imagesMain); ?>" data-barcode="<?php echo e($product->barcode); ?>">(<?php echo e($product->barcode); ?>) <?php echo e($product->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a href="<?php echo e(route('productos.administration.create')); ?>" class="input__add__user__bill btn-modal-add"><i class="fi fi-br-plus-small"></i> Añadir</a>

                        <div class="alert alert-warning" role="alert" style="margin-top: 20px; display: none;" id="alert-prod-ag">
                            El producto seleccionado, ya fue agregado
                        </div>
                    </div>
            </section>
            <div class="divider__form divider__form_icon">
                <h2>Respuestos de la orden</h2>
                <i class="fi fi-sr-shopping-cart"></i>
            </div>
            <div class="sect__form__p con__product__ord" id="con__product__ord">
                <div class="not-pro-ord" id="not-pro-ord">
                    <h5>Aún no se han agregado repuestos</h5>
                </div>
            </div>
            <div class="divider__form divider__form_icon">
                <h2>Servicios de la factura</h2>
                <i class="fi fi-sr-settings-sliders"></i>
            </div>
            <section class="sect__form__p con__servs">
                <div class="con__insert__serv">
                    <div class="inserts-serv">
                        <label>Ingresar</label>
                        <input type="number" class="form-control" id="can_serv_insert" placeholder="Cantidad Servicios" style="margin-bottom: 20px">

                        <button type="button" id="btn-inser-serv">Insertar</button>
                    </div>
                    <div class="insert__serv">
                        <button id="add-serv" type="button"><i class="fi fi-br-plus-small"></i>Insertar servicio</button>
                    </div>
                </div>
                <div class="con-serv" id="con-serv">
                    <div class="not-pro-ord not-serv-ord" id="not-serv-ord">
                        <h5>Aún no se han agregado servicios</h5>
                    </div>
                </div>
            </section>
            <div class="divider__form divider__form_icon">
                <h2>Configuración Factura</h2>
                <i class="fi fi-sr-settings-sliders"></i>
            </div>
            <section class="sect__form__p sect__setings">
                <article>
                    <h4>Preferencias Factura</h4>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="iva__check" name="iva__check" checked>
                        <label class="form-check-label" for="iva">Incluir IVA</label>
                    </div>
                </article>

                <article>
                    <h4>Estado de la factura</h4>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_paid" name="is_paid" checked>
                        <label class="form-check-label" for="is_paid">
                          Pagada
                        </label>
                    </div>
                </article>
            </section>
            <div class="divider__form divider__form_icon">
                <h2>Resumen</h2>
                <i class="fi fi-sr-calculator"></i>
            </div>
            <section class="sect__form__p sect__resume">
                <div class="info-fact">
                    <h3>IVA: </h3>
                    <p id="iva_info" class="prices">0</p>
                </div>
                <div class="info-fact">
                    <h3>Estado: </h3>
                    <p id="estado__pago">Pagada</p>
                </div>
                <div class="info-fact">
                    <h3>Subtotal: </h3>
                    <p class="con-sub-t prices" id="con-sub-t">0</p>
                </div>
                <div class="info-fact">
                    <h3>Total: </h3>
                    <p class="con-t prices" id="con-t">0</p>
                </div>
            </section>
            <section class="con__two__sub__form">
                <button type="button" id="btn__sub_bill" class="btn__subm btn btn-disabled" disabled>Crear</button>
                <a href="<?php echo e(route('productos.administration')); ?>" class="btn__back">Volver</a>
            </section>
        </form>
    </div>
</div>

<?php echo $__env->make('facturas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    var asset_global='<?php echo e(asset("/")); ?>';
    var asset_products_global='<?php echo e(asset("/img/products")); ?>';
</script>

<script src="<?php echo e(asset('libs/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/currencyPrice.js')); ?>"></script>
<script src="<?php echo e(asset('js/add-bill.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('#customers').select2({
            placeholder: "Seleccione un cliente",
            allowClear: true
        });
        $('#products').select2({
            placeholder: "Seleccione los productos",
            allowClear: true
        });
    });

    let prices = document.querySelectorAll('.prices');

    for (let i = 0; i < prices.length; i++) {
    let precio = prices[i].textContent;
        $(prices[i]).empty();
        prices[i].appendChild(document.createTextNode(formatCurrency(precio)));
    }
</script>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('link.sellers.bills')): ?>
<script>
    $(document).ready(function() {
        $('#sellers').select2({
            placeholder: "Seleccione un cliente",
            allowClear: true
        });
    });
</script>
<?php endif; ?>



<?php if(session('productsError')): ?>
    <script>
        var productsError = <?php echo json_encode(session('productsError'), 15, 512) ?>;
        $(document).ready(function() {
            errorStock(productsError);
        });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/facturas/create.blade.php ENDPATH**/ ?>