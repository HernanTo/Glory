<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('usuarios')); ?>">Usuarios</a>
            /
            <a><?php echo e($item->nameLast); ?></a>
        </div>
        <h2> <?php echo e($item->nameLast); ?> - <?php echo e($item->cc); ?></h2>
    </div>

    <div class="content-account">
        <div class="info-general-u">
            <div class="con-picture-profi">
                <img src="<?php echo e(asset('img/profileImages/' . $item->profileImg)); ?>" alt="image-profile">
            </div>
            <div class="con-info-u-b">
                <h2> <?php echo e($item->fullName); ?> </h2>
                <p><i class="fi fi-sr-briefcase"></i> <?php echo e($item->getRoleNames()->first()); ?></p>
                <p><i class="fi fi-sr-phone-call"></i> <?php echo e($item->phone_number); ?></p>
                <p><i class="fi fi-sr-envelope"></i> <?php echo e($item->emailV); ?> </p>
            </div>
            <div class="acti-acco">
                <a href="<?php echo e(route('usuarios.edit', $item->cc)); ?>">Editar</a>
                <a onclick="confirmTrash(<?php echo e($item->id); ?>, '<?php echo e($item->full_name); ?>', 1)" class="btn-elim-user">Eliminar</a>
            </div>
            <div class="con-src-accounts">
                <a href="<?php echo e(route('usuarios.usuario', $item->cc)); ?>" class="acco-active">Detalle</a>
                <a href="<?php echo e(route('usuarios.edit', $item->cc)); ?>">Editar</a>
                <?php if($item->getRoleNames()->first() == 'Vendedor'): ?>
                <a href="">Permisos</a>
                <?php endif; ?>

                <?php if($item->getRoleNames()->first() == 'Cliente'): ?>
                    <a href="">Vehículos</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="main-sec-acco">
            <div class="header-sec-ac">
                <i class="fi fi-sr-id-badge"></i>
                <h2>Detalle</h2>
                <div class="divider"></div>
                <a href="<?php echo e(route('usuarios.edit', $item->cc)); ?>">Editar</a>
            </div>
            <div class="content-sec-ac">
                <div class="con-detail-us">
                    <label>Documento</label>
                    <span> <?php echo e($item->cc); ?> </span>
                    <label>Nombre completo</label>
                    <span> <?php echo e($item->fullname); ?> </span>
                    <label>Email</label>
                    <span><?php echo e($item->emailV); ?></span>
                    <label>Telefono</label>
                    <span><?php echo e($item->phone_number); ?></span>
                    <label>Dirección</label>
                    <span><?php echo e($item->address); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/user.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('usuarios.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/usuarios/usuario.blade.php ENDPATH**/ ?>