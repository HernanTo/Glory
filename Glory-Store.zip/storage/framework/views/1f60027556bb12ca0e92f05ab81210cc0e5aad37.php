<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/css/add-product.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/editproduct.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/libs/selects/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('productos.administration')); ?>">Productos</a>
            /
            <a href="<?php echo e(route('productos.administration.show', $product->slug)); ?>"> <?php echo e($product->name); ?> </a>
            /
            <a>Editar</a>
        </div>
        <h2>Editar producto</h2>
    </div>
    <div class="container-forr">
        <form action="<?php echo e(route('productos.administration.update', $product)); ?>" method="post" class="con-sect-a-p" id="form__edit__product" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="divider__form divider__form_icon">
                <h2>Editar información básica del producto</h2>
                <i class="fi fi-sr-comment-info"></i>
            </div>
            <section class="sect__form__p">
                <div class="form-floating form__floating__glory">
                    <input type="text" class="form-control shadow-none" id="floatingInput" placeholder="Nombre producto" name="name" required value="<?php echo e($product->name); ?>">
                    <label for="floatingInput">Nombre del producto</label>
                    <i class="fi fi-sr-box-open-full ico-in"></i>
                    <?php if($errors->has('name')): ?>
                        <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="con-categ">
                    <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <select class="form-select" id="category" name="category[]" multiple="multiple" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($categoryP->id == $category->id): ?>
                                <option value="<?php echo e($category->id); ?>" selected> <?php echo e($category->name); ?> </option>
                            <?php else: ?>
                                <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('category')): ?>
                        <div class="text-danger"><?php echo e($errors->first('category')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-floating form__floating__glory">
                    <input type="text" class="form-control shadow-none" id="floatingInput" placeholder="Número de repuesto" name="num_repuesto" required value="<?php echo e($product->num_repuesto); ?>">
                    <label for="floatingInput">Número de repuesto</label>
                    <i class="fi fi-br-hastag ico-in"></i>
                    <?php if($errors->has('num_repuesto')): ?>
                        <div class="text-danger"><?php echo e($errors->first('num_repuesto')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-floating form__floating__glory">
                    <input type="text" class="form-control shadow-none" id="floatingInput" placeholder="Código de barras" name="barcode" required value="<?php echo e($product->barcode); ?>">
                    <label for="floatingInput">Código de barras</label>
                    <i class="fi fi-rr-barcode-read ico-in"></i>
                    <?php if($errors->has('barcode')): ?>
                        <div class="text-danger"><?php echo e($errors->first('barcode')); ?></div>
                    <?php endif; ?>
                </div>
            </section>

            <div class="divider__form divider__form_icon">
                <h2>Editar información de inventario</h2>
                <i class="fi fi-sr-boxes"></i>
            </div>
            <section class="sect__form__p">
                <div class="form-floating form__floating__glory">
                    <input type="text" class="form-control shadow-none" id="floatingInput" placeholder="Precio por unidad" name="price"  required value="<?php echo e($product->price); ?>" data-type='currency'>
                    <label for="floatingInput">Precio por unidad</label>
                    <i class="fi fi-ss-tags ico-in"></i>
                    <?php if($errors->has('price')): ?>
                        <div class="text-danger"><?php echo e($errors->first('price')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-floating form__floating__glory">
                    <input type="text" class="form-control shadow-none" id="floatingInput" placeholder="Precio por unidad" name="cost" required value="<?php echo e($product->cost); ?>" data-type='currency'>
                    <label for="floatingInput">Costo por unidad</label>
                    <i class="fi fi-ss-sack-dollar ico-in"></i>
                    <?php if($errors->has('cost')): ?>
                        <div class="text-danger"><?php echo e($errors->first('cost')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-floating form__floating__glory">
                    <input type="number" class="form-control shadow-none" id="floatingInput" placeholder="Cantidad de stock"  name="stock" onkeydown="return event.keyCode !== 69" required value="<?php echo e($product->stock); ?>">
                    <label for="floatingInput">Cantidad de stock</label>
                    <i class="fi fi-sr-warehouse-alt ico-in"></i>
                    <?php if($errors->has('stock')): ?>
                        <div class="text-danger"><?php echo e($errors->first('stock')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-floating form__floating__glory">
                    <input type="number" class="form-control shadow-none" id="floatingInput" placeholder="Cantidad de stock"  name="min_stock" onkeydown="return event.keyCode !== 69" required value="<?php echo e($product->min_stock); ?>">
                    <label for="floatingInput">Cantidad minima de stock</label>
                    <i class="fi fi-br-water-lower ico-in"></i>
                    <?php if($errors->has('min_stock')): ?>
                        <div class="text-danger"><?php echo e($errors->first('min_stock')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-floating form__floating__glory">
                    <select name="available" id="available" class="form-select" aria-label="Floating label select example" required>
                        <?php for($i = 0; ($i * 15) <= 60; $i++): ?>
                            <?php if($product->available == ($i * 15)): ?>
                                <?php if(($i) == 0): ?>
                                    <option value="0" selected>Inmediata</option>
                                <?php else: ?>
                                    <option value="<?php echo e($i * 15); ?>" selected><?php echo e($i * 15); ?> días</option>
                                <?php endif; ?>
                            <?php elseif(($i) == 0): ?>
                                <option value="0">Inmediata</option>
                            <?php elseif(($i * 15) != 45): ?>
                                <option value="<?php echo e($i * 15); ?>"><?php echo e($i * 15); ?> días</option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <label for="floatingInput">Disponinilidad</label>
                </div>
            </section>

            <div class="divider__form divider__form_icon">
                <h2>Editar información sobre el producto</h2>
                <i class="fi fi-sr-store-alt"></i>
            </div>
            <section class="sect__form__p">
                <div class="form-group">
                    <label for="pictures_product" class="form-label">Seleccione fotografias del producto</label>
                    <input class="form-control" type="file" id="pictures_product" name="pictures_product[]" accept="image/png,image/jpeg" multiple>
                </div>
                <h2>Registro de imagenes actuales</h2>
                <?php if(count($images) > 0): ?>
                    <div class="con__currently__images" id="con__currently__images">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="image" id="con-image-<?php echo e($image->id); ?>">
                                <img src="<?php echo e(asset('img/products/' . $image->photo)); ?>" alt="<?php echo e($product->name); ?>" class="img__prod">
                                <span id="image-<?php echo e($image->id); ?>"><i class="fi fi-ss-cross-circle"></i></span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <small class="text-danger" id="text-img">Click sobre la imagen para eliminar</small>
                        <?php else: ?>
                        <small>No existen imagenes registradas</small>
                    <?php endif; ?>
                <hr>
                <div class="form-group">
                    <label for="desc">Descripción del producto</label>
                    <textarea name="desc" id="desc" class="form-control"><?php echo e($product->description); ?></textarea>
                </div>
            </section>

            <section class="foo-add-u con__two__sub__form">
                <button type="submit" onclick="savePictures()">Crear</button>
                <a href="<?php echo e(route('productos.administration')); ?>">Volver</a>
            </section>
        </form>
    </div>
</div>

<?php echo $__env->make('productos.administration.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('libs/selects/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/products.js')); ?>"></script>
    <script src="<?php echo e(asset('js/currencyPrice.js')); ?>"></script>
    <script src="<?php echo e(asset('js/editProduct.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        var imagesArray = <?php echo json_encode($images, 15, 512) ?>;
        imagesProducts(imagesArray);

        $(document).ready(function() {
            $('#category').select2({
                placeholder: "Selecciona una categoria",
                multiple: true,
                maximumSelectionLength: 1,
                allowClear: true
            });
        });
        tinymce.init({
            language : 'es',
            selector: 'textarea#desc', // Replace this CSS selector to match the placeholder element for TinyMCE
            plugins: 'lists table help link',
            menubar: 'edit view insert help',
            toolbar: 'undo redo | formatselect| bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | table | link',
        });

        document.getElementById('pictures_product').addEventListener('change', event => {
            var filesInput = document.getElementById('pictures_product');
            var filesPath = filesInput.files;
            var allowedExtensions = /(.jpg|.jpeg|.png)$/i;

            let validation = true;

            for (let i = 0; i < filesPath.length; i++) {
                console.log(filesPath[i]);
                if(!allowedExtensions.exec(filesPath[i].name)){
                    validation = false;
                }
            }
            if(!validation){
                $('#err_img_prod').modal('show');
                filesInput.value = '';
            }
        }
        )
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/productos/administration/edit.blade.php ENDPATH**/ ?>