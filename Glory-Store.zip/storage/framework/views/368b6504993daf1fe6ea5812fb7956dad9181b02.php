<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('libs/selects/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('usuarios')); ?>">Usuarios</a>
            /
            <a>Nuevo usuario</a>
        </div>
        <h2>Nuevo usuario</h2>
    </div>
    <div class="con-add-users">
        <form action="<?php echo e(route('usuarios.store')); ?>" method="post" class="form__lin__glory" id="form__add__user">
            <?php echo csrf_field(); ?>
            <div class="divider__form">
                <h2>Información del usuario</h2>
            </div>
            <article class="form__sect">
                <div class="form-group form__group_glory">
                    <label for="cc">NIT / CC</label>
                    <input type="number" class="form-control shadow-none" name="cc" id="cc" placeholder="NIT / CC" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" value="<?php echo e(old('cc')); ?>">
                    <div class="invalid-feedback">
                        Este campo es requerido
                    </div>
                    <?php if($errors->has('cc')): ?>
                        <div class="text-danger"><?php echo e($errors->first('cc')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group form__group_glory">
                    <label for="ft_name">Primer Nombre</label>
                    <input type="text" class="form-control shadow-none" id="ft_name" name="ft_name" aria-describedby="ft_name" placeholder="Primer Nombre" value="<?php echo e(old('ft_name')); ?>">
                    <div class="invalid-feedback">
                        Este campo es requerido
                    </div>
                    <?php if($errors->has('ft_name')): ?>
                        <div class="text-danger"><?php echo e($errors->first('ft_name')); ?></div>
                    <?php endif; ?>
                    <small id="ft_name" class="form-text text-muted">Primer nombre o nombre de la organización</small>
                </div>
                <div class="form-group form__group_glory">
                    <label for="sc_name">Segundo Nombre - <span>Opcional</span></label>
                    <input type="" class="form-control shadow-none" id="sc_name" name="sc_name" placeholder="Segundo nombre" value="<?php echo e(old('sc_name')); ?>">
                </div>
                <div class="form-group form__group_glory">
                    <label for="ft_lastname">Primer Apellido - <span>Opcional</span></label>
                    <input type="text" class="form-control shadow-none" id="ft_lastname" name="ft_lastname" placeholder="Primer Apellido" value="<?php echo e(old('ft_lastname')); ?>">
                </div>
                <div class="form-group form__group_glory">
                    <label for="sc_lastname">Segundo Apellido - <span>Opcional</span></label>
                    <input type="text" class="form-control shadow-none" id="sc_lastname" name="sc_lastname" placeholder="Segundo Apellido" value="<?php echo e(old('sc_lastname')); ?>">
                </div>
            </article>
            <div class="divider__form">
                <h2>Contacto del usuario</h2>
            </div>
            <article class="form__sect">
                <div class="form-group form__group_glory">
                    <label for="email">Correo electrónico - <span>Opcional</span></label>
                    <input type="email" class="form-control shadow-none" id="email" name="email" placeholder="Correo electrónico" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group form__group_glory">
                    <label for="phone">Número de telefónico</label>
                    <input type="number" class="form-control shadow-none" id="phone" class="phone" name="phone" placeholder="Número de telefónico" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" value="<?php echo e(old('phone')); ?>">
                    <?php if($errors->has('phone')): ?>
                        <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                    <?php endif; ?>
                    <div class="invalid-feedback">
                        Este campo es requerido
                    </div>
                </div>
                <div class="form-group form__group_glory">
                    <label for="phone">Dirección</label>
                    <input type="string" class="form-control shadow-none" id="address" class="address" name="address" placeholder="Dirección" value="<?php echo e(old('address')); ?>">
                </div>
            </article>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create.workers')): ?>
                <div class="divider__form">
                    <h2>Tipo de cuenta</h2>
                </div>
                <article class="form__sect">
                    <div class="form-group form__group_glory">
                        <label for="role">Rol</label>
                        <select name="role" id="role">
                            <option value=""></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rol->name); ?>"><?php echo e($rol->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Este campo es requerido
                        </div>
                        <?php if($errors->has('role')): ?>
                            <div class="text-danger"><?php echo e($errors->first('role')); ?></div>
                        <?php endif; ?>
                    </div>
                </article>
            <?php else: ?>
                <input type="text" value="Cliente" name="role" style="display: none" id="role">
            <?php endif; ?>

            <article class="con__two__sub__form">
                <input type="button" value="Crear" class="btn__subm btn" id="subm_user">
                <a href="<?php echo e(route('usuarios')); ?>" class="btn__back">Volver</a>
            </article>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('libs/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/validateUser.js')); ?>"></script>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create.workers')): ?>
<script>
    $(document).ready(function() {
        $('#role').select2({
            placeholder: "Seleccione el rol del usuario",
            allowClear: true
        });
    });

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/usuarios/create.blade.php ENDPATH**/ ?>