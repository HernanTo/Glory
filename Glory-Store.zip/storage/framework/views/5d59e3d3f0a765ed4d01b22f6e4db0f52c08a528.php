<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('guest'); ?>
    <div class="container__login">
        <section class="con__login">
            <div class="header__con__login">
                <a href="">
                    <img src="<?php echo e(asset('img/logoc.svg')); ?>" alt="Glory Store" class="header__logo__login">
                </a>
                <h2>Iniciar sesión</h2>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        - <?php echo e($error); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-floating form__floating__glory">
                    <input type="number" class="form-control" id="floatingPassword" placeholder="Identificación" name="ide">
                    <label for="floatingPassword">Identificación</label>
                </div>
                <div class="form-floating form__floating__glory">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
                    <label for="floatingPassword">Password</label>
                </div>
                <a href="<?php echo e(route('password.request')); ?>" class="link__forg">¿Ólvido su contraseña?</a>
                <div class="con_btn">
                    <input type="submit" value="Iniciar" class="btn btn-primary btn__login">
                </div>
            </form>
            <div class="con__aler_login">
                <p>
                    ¿No tiene una cuenta?
                    <a href="<?php echo e(route('register')); ?>">Registrese</a>
                </p>

            </div>
        </section>
        <article class="aside__login">

        </article>
        <footer class="footer__login">

        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/auth/login.blade.php ENDPATH**/ ?>