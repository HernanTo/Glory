<?php $__env->startSection('title', 'Cotizaciones | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('libs/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/datatable/datatablesButtons.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a>Cotizaciones</a>
        </div>
        <h2>Cotizaciones</h2>
            <div class="con-filter">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create.bills')): ?>
                    <a class="btn-modal-add" href="<?php echo e(route('budgets.create')); ?>">
                        <i class="fi fi-br-plus-small"></i>
                        Nueva cotizacion
                    </a>
                <?php endif; ?>
                <p>Filtrar por categorias: </p>
                <div class="con-filter-da"></div>
                <div class="divider-fil"></div>
            </div>
    </div>
    <table id="table-users" class="display" style="width:100%">
        <thead>
            <tr>
                <th style="max-width: 120px">Fecha</th>
                <th style="max-width: 130px">Referencia</th>
                <th>Cliente</th>
                <th style="max-width: 120px">Total</th>
                <th style="max-width: 150px">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($budget->created_at); ?> </td>
                    <td><?php echo e($budget->reference); ?></td>
                    <td><?php echo e(($budget->customer->nameLast)); ?></td>
                    <td class="prices"> <?php echo e($budget->total); ?> </td>
                    <td class="con-actions-table">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('see.bills')): ?>
                            <a href="<?php echo e(route('budgets.budget', $budget->id)); ?>" class="actions-table action__table_show"><i class="fi fi-br-eye"></i></a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit.bills')): ?>
                            <a href="<?php echo e(route('budgets.edit', $budget->id)); ?>" class="actions-table action__table_edit"><i class="fi fi-sr-pencil"></i></a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy.bills')): ?>
                            <a onclick="confirmTrash(<?php echo e($budget->id); ?>, '<?php echo e($budget->reference); ?>')" class="actions-table action__table_delete"><i class="fi fi-sr-trash-xmark"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Fecha</th>
                <th>Referencia</th>
                <th># Cliente</th>
                <th>Total</th>
                <th>Actions</th>
            </tr>
        </tfoot>
    </table>
</div>

<?php echo $__env->make('cotizaciones.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('libs/datatable/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/datatable/datatablesButtons.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/datatable/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/datatable/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/datatable/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/datatable/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/products.js')); ?>"></script>
        <script>
            $(document).ready(function () {
            $('#table-users').DataTable({
                responsive: true,
                dom: 'Bfrtip',
                lengthMenu: [
                    [ 25, 50, 100, -1 ],
                    [ '25', '50', '100', 'Mostrar todo' ]
                ],
                buttons: [
                    'pageLength',
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [ 0, 1,2,3,4]
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: [ 0, 1,2,3,4]
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        exportOptions: {
                            columns: [ 0, 1, 2, 3,4 ]
                        }
                    },
                ],
                initComplete: function () {
                    this.api().columns([ 2 ]).every( function () {
                        var column = this;
                        var select = $('<select class="form-select form-select-sm selecttable-lotus"> <option value="">Todos</option> </select>')
                        .appendTo( $('.con-filter-da'))
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                            column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                        } );

                        column.data().unique().sort().each( function ( d, j ) {
                            if(column.search() === '^'+d+'$'){
                                select.append(
                                    '<option value="'+d+'" selected="selected">'
                                    +d+
                                    '</option>'
                                )
                            } else {
                                select.append('<option value="'+d+'">'+d+'</option>')
                            }
                        });
                    });
                },
            });
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/cotizaciones/index.blade.php ENDPATH**/ ?>