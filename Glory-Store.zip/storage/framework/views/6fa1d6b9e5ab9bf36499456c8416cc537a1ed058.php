<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('libs/xZoom/xzoom.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-product container_content">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            /
            <a><?php echo e($product->name); ?></a>
        </div>
        <h2><?php echo e($product->name); ?></h2>
    </div>
    <div class="gallery__product">
        <div class="con__main__photo xzoom-container">
            <img class="xzoom3" src="<?php echo e(asset('img/products/' . $product->ImagesMain)); ?>"></a>
        </div>
        <div class="xzoom-thumbs">
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a><img class="xzoom-gallery3" src="<?php echo e(asset('img/products/'.$image->photo)); ?>"></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <section class="section__info__basic__product">
        <div class="con__h_info_product">
            <h3> <?php echo e($product->name); ?> </h3>
            <label>Precio:</label>
            <span class="prices"> <?php echo e($product->price); ?> </span>
        </div>

        <div class="con__b__info__product">
            <?php if($product->stock > 0): ?>
            <h4>Stock disponible</h4>
            <?php else: ?>
            <h4>Stock no disponible</h4>
            <?php endif; ?>
            <?php if($product->available == 0 || $product->stock > 0): ?>
                <span class="available">Entrega nmediata</span>
            <?php endif; ?>
            <?php if($product->available == 15 && $product->stock <= 0): ?>
            <span class="available available__middle">Entrega a 15 días</span>
            <?php endif; ?>
            <?php if($product->available == 30 && $product->stock <= 0): ?>
            <span class="available available__long">Entrega a 30 días</span>
            <?php endif; ?>
            <?php if($product->available == 60 && $product->stock <= 0): ?>
            <span class="available available__long__extra">Entrega a 60 días</span>
            <?php endif; ?>

            <?php if($product->stock == 1): ?>
            <small>1 Disponible</small>
            <?php endif; ?>
            <?php if($product->stock > 1): ?>
            <small><?php echo e($product->stock); ?> Disponibles</small>
            <?php endif; ?>
        </div>
        <article class="con__actions_vertical">
            
            <a href="https://api.whatsapp.com/send/?phone=573102452756&text=Quiero+realizar+una+cotizaci%C3%B3n+de+algunos+repuestos.&type=phone_number&app_absent=0" class="btn__whatsapp__pro">
                Escribenos por Whatsapp
            </a>
        </article>
    </section>
    <section class="section__desc_product">
        <h5>Descripción del producto</h5>
        <div class="body__desc__product">
            <?php echo $product->description; ?>

        </div>
    </section>
    <section class="section__aditional__info">
        <h5>Información Adicional</h5>
        <table class="table__aditional__info">
            <tr>
                <td style="width: 130px" class="th__aditional"># de Repuesto:</td>
                <td><?php echo e($product->num_repuesto); ?></td>
            </tr>
            <tr class="th__aditional">
                <td>Barras:</td>
                <td><?php echo e($product->barcode); ?></td>
            </tr>
            <tr class="th__aditional">
                <td>Precio:</td>
                <td class="prices"><?php echo e($product->price); ?></td>
            </tr>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('see.cost.product.dash')): ?>
            <tr class="th__aditional">
                <td>Costo:</td>
                <td class="prices"><?php echo e($product->cost); ?></td>
            </tr>
            <?php endif; ?>
            <tr class="th__aditional">
                <td>Stock:</td>
                <td><?php echo e($product->stock); ?></td>
            </tr>
        </table>
    </section>
    <?php if(count($similarProducts) > 0): ?>
    
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('libs/xZoom/xzoom.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/xZoom/setup.js')); ?>"></script>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/ecommerce/producto.blade.php ENDPATH**/ ?>