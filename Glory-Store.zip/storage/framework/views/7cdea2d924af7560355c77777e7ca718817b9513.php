<?php $__env->startSection('title', 'Cotización | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bill.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('bills')); ?>">Cotización</a>
            /
            <a><?php echo e($budget->reference); ?></a>
        </div>
        <h2>Resumen Cotización</h2>
    </div>
    <div class="con-bill-summary">
        <div class="con-items-bill-s con-items-fact">
            <div class="header-items-s">
                <h2>Cotización</h2>
                <i class="fi fi-sr-receipt"></i>
            </div>
            <div class="body-items-sum body-items-fact">
                <span>
                    <label>Número de cotización</label>
                    <h3> <?php echo e($budget->reference); ?> </h3>
                    <i class="fi fi-br-hastag"></i>
                </span>

                <span>
                    <label>Fecha</label>
                    <h3> <?php echo e($budget->created_at); ?> </h3>
                    <i class="fi fi-sr-calendar-day"></i>
                </span>

                <span>
                    <label>IVA</label>

                    <h3><?php echo e($budget->haveIVA); ?></h3>
                    <i class="fi fi-sr-badge-percent"></i>
                </span>

                <span>
                    <label>Subtotal</label>
                    <h3 class="prices"> <?php echo e($budget->subtotal); ?> </h3>
                    <i class="fi fi-br-plus-minus"></i>
                </span>

                <span>
                    <label>Total</label>
                    <h3 class="prices"> <?php echo e($budget->total); ?> </h3>
                    <i class="fi fi-sr-usd-circle"></i>
                </span>
            </div>
        </div>
        <div class="actions-bill">
            <a href="<?php echo e(route('budgets.export', $budget->id)); ?>" class="export-document" target="_blank" rel="noopener noreferrer" title="Generar PDF">
                <i class="fi fi-sr-file-pdf"></i>
            </a>

            <a href="<?php echo e(route('budgets.edit', $budget->id)); ?>" class="edit-bill" title="Editar cotización">
                <i class="fi fi-sr-file-edit"></i>
            </a>

            <button class="delete-bill" title="Eliminar cotización" onclick="confirmTrash(<?php echo e($budget->id); ?>, '<?php echo e($budget->reference); ?>')"><i class="fi fi-sr-trash-xmark"></i></button>
        </div>

        <div class="con-items-bill-s con-items-min con-items-cli">
            <div class="header-items-s">
                <h2>Cliente</h2>
                <i class="fi fi-ss-user-crown"></i>
            </div>
            <div class="body-items-sum body-clien-sum">
                <p> <?php echo e($budget->customer->nameLast); ?> </p>
                <p>NIT / CC: <?php echo e($budget->customer->cc); ?></p>
                <p>Tel: <?php echo e($budget->customer->phone_number); ?></p>
                <a href="<?php echo e(route('clientes.cliente', $budget->customer->cc)); ?>" class="action-user-sum">Ver Cliente</a>
            </div>
        </div>
        <div class="con-items-bill-s con-items-min con-items-seller">
            <div class="header-items-s">
                <h2>Vendedor</h2>
                <i class="fi fi-sr-user-gear"></i>
            </div>
            <div class="body-items-sum body-seller-sum">
                <img src="<?php echo e(asset("img/profileImages/" . $budget->seller->profile_photo_path)); ?>" alt="Profile">
                <h2><?php echo e($budget->seller->nameLast); ?></h2>
                <a href="<?php echo e(route('usuarios.usuario', $budget->seller->cc)); ?>" class="action-user-sum">Ver Más</a>
            </div>
        </div>

        <div class="con-items-bill-s con-item-order-s">
            <div class="header-items-s">
                <h2>Orden</h2>
                <i class="fi fi-sr-box-open"></i>
            </div>
            <div class="body-items-sum body-order-sum">
                <h2 class="hed__prod_or">Productos</h2>

                <?php if(count($budget->products) >= 1): ?>
                    <?php $__currentLoopData = $budget->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-su">
                            <img src="<?php echo e(asset('img/products/' . $product->ImagesMain)); ?>" alt="product">
                            <h2> <?php echo e($product->NameFor); ?> </h2>
                            <h4 class="prices"><?php echo e($product->price); ?></h4>

                            <p class="cantidad-prod-s">Cantidad: <i> <?php echo e($product->pivot->stock); ?> </i></p>
                            <p class="mano-obra-su">Descuento: <i class="prices"> <?php echo e($product->pivot->discount); ?> </i></p>

                            <h1 class="prices prices-pro"> <?php echo e($product->pivot->total_prices); ?> </h1>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="product_no">
                        <h2 class="h2_not_product">Esta Cotización no cuenta con productos adjuntos</h2>
                    </div>
                <?php endif; ?>

                <div class="con-sum-prices">
                    <p>Subtotal</p>
                    <h2 class="prices"> <?php echo e($budget->subtotal); ?> </h2>

                    <p>IVA</p>
                    <?php if($budget->IVA == 1): ?>
                        <h2 class="prices"> <?php echo e($budget->subtotal * 0.19); ?> </h2>
                    <?php else: ?>
                        <h2>No aplica</h2>
                    <?php endif; ?>

                    <p>Total:</p>
                    <h2 class="prices"> <?php echo e($budget->total); ?> </h2>
                </div>
            </div>
        </div>
    </div>

</div>
<?php echo $__env->make('cotizaciones.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/cotizaciones/cotizacion.blade.php ENDPATH**/ ?>