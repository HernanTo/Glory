<?php $__env->startSection('title', 'Editar factura | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bill.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/add-bill.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('bills')); ?>">Facturas</a>
            /
            <a href="<?php echo e(route('bills.bill', $bill->id)); ?>"><?php echo e($bill->reference); ?></a>
            /
            <a>Editar</a>
        </div>
        <h2>Editar factura</h2>
    </div>
    <div class="con_child">
        <div class="alert alert-secondary" role="alert">
            Puede editar el estado de la factura y si contiene o no IVA.
        </div>
        <form action="<?php echo e(route('bills.update', $bill->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <section class="sect__form__p sect__setings">
                <article>
                    <h4>Preferencias Factura</h4>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="iva__check" name="iva__check" <?php echo e($bill->IVA ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="iva">Incluir IVA</label>
                    </div>
                </article>

                <article>
                    <h4>Estado de la factura</h4>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_paid" name="is_paid" <?php echo e($bill->is_paid ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_paid">
                          Pagada
                        </label>
                    </div>
                </article>
            </section>
            <section class="con__two__sub__form">
                <button type="submit" class="btn__subm btn">Actualizar</button>
                <a href="<?php echo e(route('productos.administration')); ?>" class="btn__back">Volver</a>
            </section>
        </form>
    </div>

</div>
<?php echo $__env->make('facturas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/facturas/edit.blade.php ENDPATH**/ ?>