<?php $__env->startSection('title', 'Factura | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bill.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('bills')); ?>">Facturas</a>
            /
            <a><?php echo e($bill->reference); ?></a>
        </div>
        <h2>Resumen factura</h2>
    </div>
    <div class="con-bill-summary">
        <div class="con-items-bill-s con-items-fact">
            <div class="header-items-s">
                <h2>Factura</h2>
                <i class="fi fi-sr-receipt"></i>
            </div>
            <div class="body-items-sum body-items-fact">
                <span>
                    <label>Número de factura</label>
                    <h3> <?php echo e($bill->reference); ?> </h3>
                    <i class="fi fi-br-hastag"></i>
                </span>

                <span>
                    <label>Fecha</label>
                    <h3> <?php echo e($bill->created_at); ?> </h3>
                    <i class="fi fi-sr-calendar-day"></i>
                </span>

                <span>
                    <label>Estado de pago</label>
                    <h3><?php echo e($bill->state); ?></h3>
                    <i class="fi fi-sr-hand-holding-usd"></i>
                </span>

                <span>
                    <label>IVA</label>

                    <h3><?php echo e($bill->haveIVA); ?></h3>
                    <i class="fi fi-sr-badge-percent"></i>
                </span>

                <span>
                    <label>Subtotal</label>
                    <h3 class="prices"> <?php echo e($bill->subtotal); ?> </h3>
                    <i class="fi fi-br-plus-minus"></i>
                </span>

                <span>
                    <label>Total</label>
                    <h3 class="prices"> <?php echo e($bill->total); ?> </h3>
                    <i class="fi fi-sr-usd-circle"></i>
                </span>
            </div>
        </div>
        <div class="actions-bill">
            <a href="<?php echo e(route('bills.export', $bill->id)); ?>" class="export-document" target="_blank" rel="noopener noreferrer" title="Generar PDF">
                <i class="fi fi-sr-file-pdf"></i>
            </a>

            <a href="<?php echo e(route('bills.edit', $bill->id)); ?>" class="edit-bill" title="Editar Factura">
                <i class="fi fi-sr-file-edit"></i>
            </a>

            <button class="delete-bill" title="Eliminar factura" onclick="confirmTrash(<?php echo e($bill->id); ?>, '<?php echo e($bill->reference); ?>')"><i class="fi fi-sr-trash-xmark"></i></button>
        </div>

        <div class="con-items-bill-s con-items-min con-items-cli">
            <div class="header-items-s">
                <h2>Cliente</h2>
                <i class="fi fi-ss-user-crown"></i>
            </div>
            <div class="body-items-sum body-clien-sum">
                <p> <?php echo e($bill->customer->nameLast); ?> </p>
                <p>NIT / CC: <?php echo e($bill->customer->cc); ?></p>
                <p>Tel: <?php echo e($bill->customer->phone_number); ?></p>
                <a href="<?php echo e(route('clientes.cliente', $bill->customer->cc)); ?>" class="action-user-sum">Ver Cliente</a>
            </div>
        </div>
        <div class="con-items-bill-s con-items-min con-items-seller">
            <div class="header-items-s">
                <h2>Vendedor</h2>
                <i class="fi fi-sr-user-gear"></i>
            </div>
            <div class="body-items-sum body-seller-sum">
                <img src="<?php echo e(asset("img/profileImages/" . $bill->seller->profile_photo_path)); ?>" alt="Profile">
                <h2><?php echo e($bill->seller->nameLast); ?></h2>
                <a href="<?php echo e(route('usuarios.usuario', $bill->seller->cc)); ?>" class="action-user-sum">Ver Más</a>
            </div>
        </div>

        <div class="con-items-bill-s con-item-order-s">
            <div class="header-items-s">
                <h2>Orden</h2>
                <i class="fi fi-sr-box-open"></i>
            </div>
            <div class="body-items-sum body-order-sum">
                <h2 class="hed__prod_or">Productos</h2>

                <?php if(count($bill->products) >= 1): ?>
                    <?php $__currentLoopData = $bill->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-su">
                            <img src="<?php echo e(asset('img/products/' . $product->ImagesMain)); ?>" alt="product">
                            <h2> <?php echo e($product->NameFor); ?> </h2>
                            <h4 class="prices"><?php echo e($product->price); ?></h4>

                            <p class="cantidad-prod-s">Cantidad: <i> <?php echo e($product->pivot->stock); ?> </i></p>
                            <p class="mano-obra-su">Descuento: <i class="prices"> <?php echo e($product->pivot->discount); ?> </i></p>

                            <h1 class="prices prices-pro"> <?php echo e($product->pivot->total_prices); ?> </h1>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="product_no">
                        <h2 class="h2_not_product">Esta factura no cuenta con productos adjuntos</h2>
                    </div>
                <?php endif; ?>

                <div class="con__sum__services">
                    <h2>Servicios</h2>
                    <?php if(count($bill->services) >= 1): ?>
                        <?php $__currentLoopData = $bill->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="serv">
                                <h3> <?php echo e($service->name); ?> </h3>
                                <h5 class="prices prices-pro"> <?php echo e($service->price); ?> </h5>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="serv serv_no">
                            <h2>Esta factura no cuenta con servicios adjuntos</h2>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="con-sum-prices">
                    <p>Subtotal</p>
                    <h2 class="prices"> <?php echo e($bill->subtotal); ?> </h2>

                    <p>IVA</p>
                    <?php if($bill->IVA == 1): ?>
                        <h2 class="prices"> <?php echo e($bill->subtotal * 0.19); ?> </h2>
                    <?php else: ?>
                        <h2>No aplica</h2>
                    <?php endif; ?>

                    <p>Total:</p>
                    <h2 class="prices"> <?php echo e($bill->total); ?> </h2>
                </div>
            </div>
        </div>
    </div>

</div>
<?php echo $__env->make('facturas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/facturas/bill.blade.php ENDPATH**/ ?>