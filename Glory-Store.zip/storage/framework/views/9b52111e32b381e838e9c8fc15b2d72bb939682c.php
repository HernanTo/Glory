<?php $__env->startSection('title', 'Catálogo | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('libs/xZoom/xzoom.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container_content">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            /
            <a>Catálogo</a>
        </div>
        <h2>Catálogo</h2>
    </div>
    <section class="con__categories">
        <a href="<?php echo e(route('catalogo')); ?>" class="category_btn">
            <i class="fi fi-ss-box-open-full"></i>
            <h3>Catálogo</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Caja')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/gearbox.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Caja</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Exteriores')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/car.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Exteriores</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Motor')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/car-engine.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Motor</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Suspension')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/suspension.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Supensión</h3>
        </a>
    </section>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($category->products) > 0): ?>
            <section class="con__section_prods">
                <div class="header__section__prods">
                    <h2><?php echo e($category->name); ?></h2>
                    <a href="<?php echo e(route('category.productos', $category->name)); ?>">Ver todos</a>
                </div>
                <div class="con__products">
                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('producto.producto', $product->slug)); ?>" class="product">
                        <figure class="con__img_prod">
                            <img src="<?php echo e(asset('img/products/' . $product->imagesMain)); ?>" alt="<?php echo e($product->slug); ?>">
                        </figure>
                        <div class="info__prod">
                            <div class="con__name_prod">
                                <h3><?php echo e($product->nameFor); ?></h3>
                            </div>
                            <div class="con_bottom_prod">
                                <span class="prices"><?php echo e($product->price); ?> </span>
                                <button class="btn__add__car"><i class="fi fi-sr-shopping-cart-add"></i></button>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/ecommerce/catalogo.blade.php ENDPATH**/ ?>