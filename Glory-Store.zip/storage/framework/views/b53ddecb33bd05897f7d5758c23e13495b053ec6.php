<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container_content">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            /
            <a><?php echo e($category->name); ?></a>
        </div>
        <h2><?php echo e($category->name); ?></h2>
    </div>
    <?php if(count($category->products) > 0): ?>
        <article class="con__filter__list">
            <form action="" method="get" id="search_filter">
                <label for="">Ordernar por</label>
                <select name="" id="" class="order__select">
                    <option value="asc">Relevancia</option>
                    <option value="asc">Mayor precio</option>
                    <option value="asc">Menor precio</option>
                </select>
            </form>
        </article>
        <div class="con__products">
        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('producto.producto', $product->slug)); ?>" class="product">
                <figure class="con__img_prod">
                    <img src="<?php echo e(asset('img/products/' . $product->imagesMain)); ?>" alt="<?php echo e($product->slug); ?>">
                </figure>
                <div class="info__prod">
                    <div class="con__name_prod">
                        <h3><?php echo e($product->nameFor); ?></h3>
                    </div>
                    <div class="con_bottom_prod">
                        <span class="prices"><?php echo e($product->price); ?> </span>
                        <button class="btn__add__car"><i class="fi fi-sr-shopping-cart-add"></i></button>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <section class="products__not__found">
            <i class="fi fi-ss-binoculars"></i>
            <div class="con__list__ps">
                <h2>No se encontraron repuestos</h2>
                <ul>
                    <li>Verifique su busqueda</li>
                    <li>Refresque la página</li>
                    <li>La página ya no existe</li>
                    <li>Ingresaste una URL incorrecta</li>
                </ul>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/ecommerce/categoria.blade.php ENDPATH**/ ?>