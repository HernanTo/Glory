<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('usuarios')); ?>">Usuarios</a>
            /
            <a><?php echo e($item->nameLast); ?></a>
        </div>
        <h2> <?php echo e($item->nameLast); ?> - <?php echo e($item->cc); ?></h2>
    </div>

    <div class="content-account">
        <div class="info-general-u">
            <div class="con-picture-profi">
                <img src="<?php echo e(asset('img/profileImages/' . $item->profileImg)); ?>" alt="image-profile">
            </div>
            <div class="con-info-u-b">
                <h2> <?php echo e($item->fullName); ?> </h2>
                <p><i class="fi fi-sr-briefcase"></i> Cliente</p>
                <p><i class="fi fi-sr-phone-call"></i> <?php echo e($item->phone_number); ?></p>
                <p><i class="fi fi-sr-envelope"></i> <?php echo e($item->emailV); ?> </p>
            </div>
            <div class="acti-acco">
                <a href="<?php echo e(route('clientes.edit', $item->cc)); ?>">Editar</a>
                <a onclick="" class="btn-elim-user">Eliminar</a>
            </div>
            <div class="con-src-accounts">
                <a href="<?php echo e(route('clientes.cliente', $item->cc)); ?>" class="acco-active">Detalle</a>
                <a href="<?php echo e(route('clientes.edit', $item->cc)); ?>">Editar</a>
                <a href="">Vehículos</a>
            </div>
        </div>

        <div class="main-sec-acco">
            <div class="header-sec-ac">
                <i class="fi fi-sr-id-badge"></i>
                <h2>Detalle</h2>
                <div class="divider"></div>
                <a href="<?php echo e(route('clientes.edit', $item->cc)); ?>">Editar</a>
            </div>
            <div class="content-sec-ac">
                <div class="con-detail-us">
                    <label>Documento</label>
                    <span> <?php echo e($item->cc); ?> </span>
                    <label>Nombre completo</label>
                    <span> <?php echo e($item->fullname); ?> </span>
                    <label>Email</label>
                    <span><?php echo e($item->emailV); ?></span>
                    <label>Telefono</label>
                    <span><?php echo e($item->phone_number); ?></span>
                    <label>Dirección</label>
                    <span><?php echo e($item->address); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('usuarios.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/clientes/cliente.blade.php ENDPATH**/ ?>