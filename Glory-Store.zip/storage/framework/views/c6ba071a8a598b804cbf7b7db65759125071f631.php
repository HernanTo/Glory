<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner">
    <div id="carousel__desk" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-current="true" aria-label="Slide2"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="5000">
            <img src="<?php echo e(asset('img/glory.jpg')); ?>" class="d-block w-100" alt="">
          </div>
          <div class="carousel-item" data-bs-interval="5000">
            <img src="<?php echo e(asset('img/glory_sup.jpg')); ?>" class="d-block w-100" alt="">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
    </div>
    <div id="carousel__mobile" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-current="true" aria-label="Slide2"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="5000">
              <img src="<?php echo e(asset('img/glory.jpg')); ?>" class="d-block w-100" alt="">
            </div>
            <div class="carousel-item" data-bs-interval="5000">
              <img src="<?php echo e(asset('img/glory_sup.jpg')); ?>" class="d-block w-100" alt="">
            </div>
          </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
    </div>
</section>
<div class="container_content">
    <section class="con__categories">
        <a href="<?php echo e(route('catalogo')); ?>" class="category_btn">
            <i class="fi fi-ss-box-open-full"></i>
            <h3>Catálogo</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Caja')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/gearbox.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Caja</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Exteriores')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/car.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Exteriores</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Motor')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/car-engine.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Motor</h3>
        </a>
        <a href="<?php echo e(route('category.productos', 'Suspension')); ?>" class="category_btn">
            <figure>
                <img src="<?php echo e(asset('img/suspension.png')); ?>" alt="" class="ico__category">
            </figure>
            <h3>Supensión</h3>
        </a>
    </section>
    <section class="con__section_prods">
        <div class="header__section__prods">
            <h2>Nuevos Productos</h2>
        </div>
        <div class="con__products">
            <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('producto.producto', $product->slug)); ?>" class="product">
                    <figure class="con__img_prod">
                        <img src="<?php echo e(asset('img/products/' . $product->imagesMain)); ?>" alt="<?php echo e($product->slug); ?>">
                    </figure>
                    <div class="info__prod">
                        <div class="con__name_prod">
                            <h3><?php echo e($product->nameFor); ?></h3>
                        </div>
                        <div class="con_bottom_prod">
                            <span class="prices"><?php echo e($product->price); ?> </span>
                            <button class="btn__add__car"><i class="fi fi-sr-shopping-cart-add"></i></button>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    

    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/ecommerce/index.blade.php ENDPATH**/ ?>