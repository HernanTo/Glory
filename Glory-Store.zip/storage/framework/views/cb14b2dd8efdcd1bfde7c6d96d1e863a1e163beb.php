<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('libs/selects/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-index-user con-acount-general">
        <div class="header-table header__table__left">
            <div class="bread-cump">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
                /
                <a href="<?php echo e(route('usuarios')); ?>">Usuarios</a>
                /
                <a href="<?php echo e(route('usuarios.usuario', $item->cc)); ?>"><?php echo e($item->nameLast); ?></a>
                /
                <a>Editar</a>
            </div>
            <h2> <?php echo e($item->nameLast); ?> - <?php echo e($item->cc); ?> - Editar</h2>
        </div>

        <div class="content-account content__edit">
            <div class="info-general-u">
                <div class="con-picture-profi">
                    <img src="<?php echo e(asset('img/profileImages/' . $item->profileImg)); ?>" alt="image-profile">
                </div>
                <div class="con-info-u-b">
                    <h2> <?php echo e($item->fullName); ?> </h2>
                    <p><i class="fi fi-sr-briefcase"></i> <?php echo e($item->getRoleNames()->first()); ?></p>
                    <p><i class="fi fi-sr-phone-call"></i> <?php echo e($item->phone_number); ?></p>
                    <p><i class="fi fi-sr-envelope"></i> <?php echo e($item->emailV); ?> </p>
                </div>
                <div class="acti-acco">
                    
                    <a onclick="confirmTrash(<?php echo e($item->id); ?>, '<?php echo e($item->full_name); ?>', 1)" class="btn-elim-user">Eliminar</a>
                </div>
                <div class="con-src-accounts">
                    <a href="<?php echo e(route('usuarios.usuario', $item->cc)); ?>">Detalle</a>
                    <a href="<?php echo e(route('usuarios.edit', $item->cc)); ?>" class="acco-active">Editar</a>
                    <?php if($item->getRoleNames()->first() == 'Vendedor'): ?>
                    <a href="">Permisos</a>
                    <?php endif; ?>

                    <?php if($item->getRoleNames()->first() == 'Cliente'): ?>
                        <a href="">Vehículos</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="main-sec-acco" id="sec__data">
                <div class="header-sec-ac header-ac">
                    <i class="fi fi-sr-id-badge"></i>
                    <h2>Editar</h2>
                    <div class="divider"></div>
                </div>
                <div class="content-sec-ac">
                    
                    <form action="<?php echo e(route('usuarios.update', $item)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="con-detail-us-f">
                            <section class="edit-two-c-ac">
                                <label>Avatar</label>
                                <div class="con-img-prof-e">
                                    <img src="<?php echo e(asset('img/profileImages/' . $item->profileImg)); ?>" alt="foto-profile" class="edit-profile-img" id="edit-profile-img">

                                    <div class="trash-pic" id="trash-pic" title="Eliminar avatar"> <i class="fi fi-sr-broom"></i> </div>

                                    <label for="img-profil-c" class="edit-picture-profi"  title="Editar avatar"><i class="fi fi-ss-pencil"></i></label>


                                    <input type="file" name="imgeProfile" id="img-profil-c" style="display: none" accept="image/png,image/jpeg">
                                    <input type="number" name="changepicturestate" value="0" id="changepicturestate" style="display: none;">
                                    <?php if($errors->has('img-profil-c')): ?>
                                        <div class="text-danger"><?php echo e($errors->first('ft_name')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>NIT / CC</label>
                                <input type="number" name="cc" id="cc" value="<?php echo e($item->cc); ?>" required placeholder="NIT / CC" class="form-control shadow-none">
                                <?php if($errors->has('cc')): ?>
                                    <span>-</span>
                                    <div class="text-danger"><?php echo e($errors->first('cc')); ?></div>
                                <?php endif; ?>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>Nombres</label>
                                <span>
                                    <input type="text" name="ft_name" id="ft_name" value="<?php echo e($item->ft_name); ?>" placeholder="Primer Nombre" class="form-control shadow-none" required>
                                    <?php if($errors->has('ft_name')): ?>
                                        <div class="text-danger"><?php echo e($errors->first('ft_name')); ?></div>
                                    <?php endif; ?>
                                    <input type="text" name="sc_name" id="sd_name" value="<?php echo e($item->sc_name); ?>" placeholder="Segundo Nombre" class="form-control shadow-none">
                                </span>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>Apellidos</label>
                                <span>
                                    <input type="text" name="fi_lastname" id="fi_lastname" value="<?php echo e($item->fi_lastname); ?>" placeholder="Primer Apellido" class="form-control shadow-none">
                                    <input type="text" name="sc_lastname" id="sc_lastname" value="<?php echo e($item->sc_lastname); ?>" placeholder="Segundo Apellido" class="form-control shadow-none">
                                </span>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>Email</label>
                                <input type="email" name="email" id="email" value="<?php echo e($item->email); ?>" placeholder="Email" class="form-control shadow-none">
                                <?php if($errors->has('email')): ?>
                                    <span>-</span>
                                    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>Teléfono</label>
                                <input type="number" name="phone" id="phone" value="<?php echo e($item->phone_number); ?>" required placeholder="Teléfono" class="form-control shadow-none">
                                <?php if($errors->has('phone')): ?>
                                    <span>-</span>
                                    <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                                <?php endif; ?>
                            </section>
                            <section class="edit-two-c-ac form__group_glory">
                                <label>Dirección</label>
                                <input type="text" name="address" id="address" value="<?php echo e($item->address); ?>" placeholder="Dirección" class="form-control shadow-none">
                            </section>
                            <section class="con-sub-edi-p">
                                <input type="submit" value="Actualizar datos" class="btn__subm btn">
                            </section>
                        </div>
                    </form>
                </div>

            </div>
            <?php if($item->getRoleNames()->first() != 'Cliente'): ?>
                <div class="main-sec-acco" id="sec__rol">
                    <div class="header-sec-ac header-ac">
                        <i class="fi fi-sr-users-gear"></i>
                        <h2>Editar Rol</h2>
                        <div class="divider"></div>
                    </div>
                    <div class="content-sec-ac content__sec__ac__rol">
                        <form action="<?php echo e(route('usuarios.updateRole', $item)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group form__group_glory" style="margin-bottom: 20px">
                                <div class="form-group form__group_glory">
                                    <div class="form-group form__group_glory">
                                        <label for="role">Nuevo rol</label>
                                        <select name="role" id="role" required>
                                            <option value=""></option>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rol->name); ?>"><?php echo e($rol->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('email')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('role')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <section class="con-sub-edi-p">
                                <input type="submit" value="Editar rol" class="btn__subm btn">
                            </section>
                        </form>
                    </div>

                </div>
            <?php endif; ?>
        </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('usuarios.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var asset_global='<?php echo e(asset("/")); ?>';
    var asset_user_global='<?php echo e(asset("/img/profileImages")); ?>';
</script>

<script src="<?php echo e(asset('libs/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/editUser.js')); ?>"></script>
<script src="<?php echo e(asset('js/user.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#role').select2({
            placeholder: "Seleccione el rol del usuario",
            allowClear: true
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>