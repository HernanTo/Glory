<?php $__env->startSection('title', 'Editar Cotización | Glory Store'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bill.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/add-bill.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-index-user conrtainer-table-d">
    <div class="header-table header__table__left">
        <div class="bread-cump">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            /
            <a href="<?php echo e(route('budgets')); ?>">Cotización</a>
            /
            <a href="<?php echo e(route('budgets.budget', $budget->id)); ?>"><?php echo e($budget->reference); ?></a>
            /
            <a>Editar</a>
        </div>
        <h2>Editar Cotización</h2>
    </div>
    <div class="con_child">
        <div class="alert alert-secondary" role="alert">
            Puede editar si la cotización incluye IVA
        </div>
        <form action="<?php echo e(route('budgets.update', $budget->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <section class="sect__form__p sect__setings">
                <article>
                    <h4>Preferencias de la cotización</h4>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="iva__check" name="iva__check" <?php echo e($budget->IVA ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="iva">Incluir IVA</label>
                    </div>
                </article>
            </section>
            <section class="con__two__sub__form">
                <button type="submit" class="btn__subm btn">Actualizar</button>
                <a href="<?php echo e(route('productos.administration')); ?>" class="btn__back">Volver</a>
            </section>
        </form>
    </div>

</div>
<?php echo $__env->make('cotizaciones.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/products.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_lts\htdocs\Glory-Store\resources\views/cotizaciones/edit.blade.php ENDPATH**/ ?>